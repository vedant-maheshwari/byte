const { GoogleGenerativeAI } = require("@google/generative-ai");
require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json()); // Add JSON parsing for API requests
app.use(express.static(__dirname)); // Serve static files (index.html, script.js)

// Serve the frontend
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Initialize Gemini API
const genAI = new GoogleGenerativeAI(process.env.API_KEY);
const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

// Generate story function
const generateStory = async (topic, style, sceneCount) => {
    const prompt = `
        Create a story about "${topic}" in ${style} style with ${sceneCount} scenes.
        For each scene, provide:
        1. A title
        2. A detailed description
        3. Characters present (with names and descriptions)
        4. Key actions and events
        5. Visual setting description (for potential image/GIF generation)
        
        Format the response as a JSON object:
        {
            "title": "Story Title",
            "description": "Overall story description",
            "scenes": [
                {
                    "id": 0,
                    "title": "Scene 1 Title",
                    "description": "Detailed scene description",
                    "setting": "Visual setting description",
                    "characters": [
                        {"id": "char1", "name": "Character Name", "description": "Character description"}
                    ],
                    "actions": ["Action 1", "Action 2"]
                }
            ]
        }
    `;
    
    try {
        const result = await model.generateContent(prompt);
        const text = result.response.text();
        
        // Extract JSON from the response (assuming Gemini returns it in ```json``` format)
        const jsonMatch = text.match(/```json\s*([\s\S]*?)\s*```/) || text.match(/\{[\s\S]*\}/);
        if (!jsonMatch) throw new Error("Invalid JSON response from Gemini");
        
        const storyData = JSON.parse(jsonMatch[1] || jsonMatch[0]);
        console.log("Generated story:", storyData);
        return storyData;
    } catch (error) {
        console.error('Error generating story:', error);
        throw error;
    }
};

// API endpoint for story generation
app.post('/api/generate-story', async (req, res) => {
    try {
        const { topic, style, sceneCount } = req.body;
        if (!topic || !style || !sceneCount) {
            return res.status(400).json({ error: "Missing required fields: topic, style, or sceneCount" });
        }

        const storyData = await generateStory(topic, style, parseInt(sceneCount));
        res.json(storyData);
    } catch (error) {
        res.status(500).json({ error: "Failed to generate story: " + error.message });
    }
});

app.listen(3000, () => {
    console.log('Server is running on http://localhost:3000');
});