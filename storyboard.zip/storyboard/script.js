// Main JavaScript for the app
class StoryCanvas {
    constructor() {
        this.scenes = [];
        this.currentSceneIndex = 0;
        this.isPlaying = false;
        this.renderer = null;
        this.camera = null;
        this.scene = null;
        this.sceneObjects = [];
        this.characters = {};
        
        // Initialize the Gemini service
        this.geminiService = new GeminiService();
        
        // Initialize the app
        this.init();
    }
    
    init() {
        // Set up event listeners
        document.getElementById('generateBtn').addEventListener('click', this.generateStory.bind(this));
        document.getElementById('playBtn').addEventListener('click', this.togglePlayback.bind(this));
        document.getElementById('sceneCount').addEventListener('input', this.updateSceneCount.bind(this));
        
        // Initialize 3D scene
        this.setupThreeJS();
    }
    
    setupThreeJS() {
        const container = document.getElementById('sceneCanvas');
        
        // Check if the container exists
        if (!container) {
            console.error('Canvas element with ID "sceneCanvas" not found');
            return;
        }
        
        // Scene setup
        this.scene = new THREE.Scene();
        this.scene.background = new THREE.Color(0x2a2a2a);
        
        // Camera setup
        this.camera = new THREE.PerspectiveCamera(75, container.clientWidth / container.clientHeight, 0.1, 1000);
        this.camera.position.z = 5;
        
        // Renderer setup
        this.renderer = new THREE.WebGLRenderer({ canvas: container, antialias: true });
        this.renderer.setSize(container.clientWidth, container.clientHeight);
        
        // Lighting
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
        this.scene.add(ambientLight);
        
        const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
        directionalLight.position.set(1, 1, 1);
        this.scene.add(directionalLight);
        
        // Handle window resize
        window.addEventListener('resize', () => {
            const container = document.getElementById('sceneCanvas');
            if (!container) return;
            
            this.camera.aspect = container.clientWidth / container.clientHeight;
            this.camera.updateProjectionMatrix();
            this.renderer.setSize(container.clientWidth, container.clientHeight);
        });
        
        // Initial render
        this.animate();
    }
    
    animate() {
        if (!this.renderer) return;
        
        requestAnimationFrame(this.animate.bind(this));
        
        // Animation logic here
        if (this.sceneObjects.length > 0) {
            this.sceneObjects.forEach(obj => {
                if (obj.rotation) {
                    obj.rotation.y += 0.01;
                }
            });
        }
        
        this.renderer.render(this.scene, this.camera);
    }
    
    updateSceneCount() {
        const counter = document.getElementById('sceneCount');
        const display = document.getElementById('sceneCountValue');
        if (counter && display) {
            display.textContent = counter.value;
        }
    }
    
    async generateStory() {
        const topicElement = document.getElementById('storyTopic');
        const styleElement = document.getElementById('storyStyle');
        const sceneCountElement = document.getElementById('sceneCount');
        
        if (!topicElement || !styleElement || !sceneCountElement) {
            console.error('Required input elements not found');
            alert('Missing required form elements. Please check the page structure.');
            return;
        }
        
        const topic = topicElement.value;
        const style = styleElement.value;
        const sceneCount = sceneCountElement.value;
        
        if (!topic) {
            alert('Please enter a topic for your story');
            return;
        }
        
        // Show loading state
        const loadingState = document.getElementById('loadingState');
        const storyDisplay = document.getElementById('storyDisplay');
        
        if (loadingState) loadingState.classList.remove('hidden');
        if (storyDisplay) storyDisplay.classList.add('hidden');
        
        try {
            // Generate story using Gemini API
            await this.updateLoadingState('Generating story narrative...');
            const storyData = await this.callGeminiAPI(topic, style, sceneCount);
            
            // Process story data
            await this.updateLoadingState('Creating visual scenes...');
            await this.processStoryData(storyData);
            
            // Generate 3D scenes
            await this.updateLoadingState('Building 3D environments...');
            await this.createScenes();
            
            // Hide loading, show results
            if (loadingState) loadingState.classList.add('hidden');
            if (storyDisplay) storyDisplay.classList.remove('hidden');
            
            // Display the first scene
            this.showScene(0);
            
        } catch (error) {
            console.error('Error generating story:', error);
            alert('There was an error generating your story. Please try again.\n\n' + error.message);
            if (loadingState) loadingState.classList.add('hidden');
        }
    }
    
    async updateLoadingState(message) {
        const loadingStage = document.getElementById('loadingStage');
        if (loadingStage) {
            loadingStage.textContent = message;
        }
        // Log for debugging
        console.log('Loading stage:', message);
        
        // Simulate processing time for demo purposes
        return new Promise(resolve => setTimeout(resolve, 1500));
    }
    
    async callGeminiAPI(topic, style, sceneCount) {
        console.log('Calling Gemini API with:', { topic, style, sceneCount });
        
        try {
            // Use the Gemini service to generate the story
            return await this.geminiService.generateStory(topic, style, sceneCount);
        } catch (error) {
            console.error('Error in Gemini API call:', error);
            
            // Fall back to mock data if the API call fails
            console.log('Falling back to mock data');
            return {
                title: `The Adventure of ${topic}`,
                description: `A captivating story about ${topic} told in ${sceneCount} scenes.`,
                scenes: Array.from({ length: parseInt(sceneCount) }, (_, i) => ({
                    id: i,
                    title: `Scene ${i + 1}`,
                    description: `This is scene ${i + 1} of the story about ${topic}.`,
                    setting: i === 0 ? 'introduction' : i === sceneCount - 1 ? 'conclusion' : 'middle',
                    characters: [
                        { id: 'main', name: 'Protagonist', description: 'The main character' },
                        { id: 'support', name: 'Supporting Character', description: 'Helps the protagonist' }
                    ],
                    actions: [
                        `Character movement ${i}`,
                        `Dialogue moment ${i}`,
                        `Environment change ${i}`
                    ]
                }))
            };
        }
    }
    
    async processStoryData(storyData) {
        // Display story text
        const storyTextContainer = document.getElementById('storyText');
        if (!storyTextContainer) {
            console.error('Story text container not found');
            return;
        }
        
        storyTextContainer.innerHTML = `
            <h3 class="text-xl font-bold mb-2">${storyData.title}</h3>
            <p class="mb-4">${storyData.description}</p>
            <div class="space-y-4">
                ${storyData.scenes.map(scene => `
                    <div class="border-l-4 border-purple-500 pl-4">
                        <h4 class="font-bold">${scene.title}</h4>
                        <p>${scene.description}</p>
                    </div>
                `).join('')}
            </div>
        `;
        
        // Save scenes data
        this.scenes = storyData.scenes;
        
        // Create scene thumbnails
        const thumbnailContainer = document.getElementById('sceneThumbnails');
        if (!thumbnailContainer) {
            console.error('Thumbnail container not found');
            return;
        }
        
        thumbnailContainer.innerHTML = '';
        
        storyData.scenes.forEach((scene, index) => {
            const thumbnail = document.createElement('div');
            thumbnail.className = 'flex-shrink-0 w-24 h-16 bg-gray-300 rounded cursor-pointer flex items-center justify-center';
            thumbnail.textContent = `Scene ${index + 1}`;
            thumbnail.addEventListener('click', () => this.showScene(index));
            thumbnailContainer.appendChild(thumbnail);
        });
    }
    
    async createScenes() {
        if (!this.scene) {
            console.error('Three.js scene not initialized');
            return;
        }
        
        // Clear existing scene objects
        while(this.scene.children.length > 0) { 
            this.scene.remove(this.scene.children[0]); 
        }
        
        // Add basic lighting
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
        this.scene.add(ambientLight);
        
        const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
        directionalLight.position.set(1, 1, 1);
        this.scene.add(directionalLight);
        
        // Create character models once to reuse
        await this.createCharacters();
        
        // Process each scene
        this.sceneObjects = this.scenes.map((sceneData, index) => {
            // Create a group for this scene
            const sceneGroup = new THREE.Group();
            sceneGroup.visible = false; // Hide initially
            
            // Add a background for this scene
            const bgGeometry = new THREE.PlaneGeometry(10, 6);
            const bgMaterial = new THREE.MeshBasicMaterial({ 
                color: this.getSceneColor(index),
                side: THREE.DoubleSide
            });
            const background = new THREE.Mesh(bgGeometry, bgMaterial);
            background.position.z = -2;
            sceneGroup.add(background);
            
            // Add characters to this scene
            if (this.characters.main && this.characters.support) {
                const mainCharClone = this.characters.main.clone();
                mainCharClone.position.set(-1.5, -1, 0);
                sceneGroup.add(mainCharClone);
                
                const supportCharClone = this.characters.support.clone();
                supportCharClone.position.set(1.5, -1, 0);
                sceneGroup.add(supportCharClone);
            }
            
            // Add scene-specific elements
            const geometries = [
                new THREE.BoxGeometry(0.5, 0.5, 0.5),
                new THREE.SphereGeometry(0.3, 32, 32),
                new THREE.ConeGeometry(0.3, 0.6, 32)
            ];
            
            for (let i = 0; i < 3; i++) {
                const material = new THREE.MeshStandardMaterial({ 
                    color: Math.random() * 0xffffff 
                });
                const object = new THREE.Mesh(geometries[i % geometries.length], material);
                object.position.set(
                    (Math.random() - 0.5) * 4,
                    (Math.random() - 0.5) * 2,
                    (Math.random() - 0.5) * 2
                );
                sceneGroup.add(object);
            }
            
            this.scene.add(sceneGroup);
            return sceneGroup;
        });
        
        console.log(`Created ${this.sceneObjects.length} scene objects`);
    }
    
    async createCharacters() {
        // Create simple character representations
        this.characters = {};
        
        // Main character
        const mainChar = new THREE.Group();
        
        // Body
        const bodyGeometry = new THREE.BoxGeometry(0.5, 0.8, 0.3);
        const bodyMaterial = new THREE.MeshStandardMaterial({ color: 0x3366ff });
        const body = new THREE.Mesh(bodyGeometry, bodyMaterial);
        body.position.y = 0.4;
        
        // Head
        const headGeometry = new THREE.SphereGeometry(0.25, 32, 32);
        const headMaterial = new THREE.MeshStandardMaterial({ color: 0xffcc99 });
        const head = new THREE.Mesh(headGeometry, headMaterial);
        head.position.y = 1;
        
        // Limbs
        const limbGeometry = new THREE.BoxGeometry(0.15, 0.5, 0.15);
        const limbMaterial = new THREE.MeshStandardMaterial({ color: 0x3366ff });
        
        const leftArm = new THREE.Mesh(limbGeometry, limbMaterial);
        leftArm.position.set(0.35, 0.4, 0);
        
        const rightArm = new THREE.Mesh(limbGeometry, limbMaterial);
        rightArm.position.set(-0.35, 0.4, 0);
        
        const leftLeg = new THREE.Mesh(limbGeometry, limbMaterial);
        leftLeg.position.set(0.15, -0.3, 0);
        
        const rightLeg = new THREE.Mesh(limbGeometry, limbMaterial);
        rightLeg.position.set(-0.15, -0.3, 0);
        
        mainChar.add(body, head, leftArm, rightArm, leftLeg, rightLeg);
        this.characters.main = mainChar;
        
        // Supporting character - similar but different color
        const supportChar = mainChar.clone();
        supportChar.traverse(child => {
            if (child.isMesh && child.material.color) {
                if (child.material.color.getHex() === 0x3366ff) {
                    child.material = child.material.clone();
                    child.material.color.set(0x33cc33);
                }
            }
        });
        this.characters.support = supportChar;
    }
    
    getSceneColor(index) {
        // Generate different background colors for different scene types
        if (!this.scenes || !this.scenes[index]) {
            return 0xADD8E6; // Default light blue
        }
        
        const sceneType = this.scenes[index].setting;
        
        switch(sceneType) {
            case 'introduction':
                return 0x87CEEB; // Sky blue
            case 'conclusion':
                return 0xFFD700; // Gold
            default:
                // Different colors for middle scenes
                const colors = [0xADD8E6, 0x98FB98, 0xFFA07A, 0xE6E6FA, 0xFFDAB9];
                return colors[index % colors.length];
        }
    }
    
    showScene(index) {
        if (!this.sceneObjects || this.sceneObjects.length === 0) {
            console.error('No scene objects available');
            return;
        }
        
        // Hide all scenes
        this.sceneObjects.forEach(obj => {
            obj.visible = false;
        });
        
        // Show selected scene
        if (this.sceneObjects[index]) {
            this.sceneObjects[index].visible = true;
            this.currentSceneIndex = index;
            
            // Update progress bar
            const progressBar = document.getElementById('progressBar');
            if (progressBar) {
                const progress = (index / (this.scenes.length - 1)) * 100;
                progressBar.style.width = `${progress}%`;
            }
            
            // Highlight active thumbnail
            const thumbnailContainer = document.getElementById('sceneThumbnails');
            if (thumbnailContainer) {
                const thumbnails = thumbnailContainer.children;
                Array.from(thumbnails).forEach((thumbnail, i) => {
                    if (i === index) {
                        thumbnail.classList.add('ring-2', 'ring-purple-600');
                    } else {
                        thumbnail.classList.remove('ring-2', 'ring-purple-600');
                    }
                });
            }
        } else {
            console.error(`Scene at index ${index} not found`);
        }
    }
    
    togglePlayback() {
        if (this.isPlaying) {
            this.stopPlayback();
        } else {
            this.startPlayback();
        }
    }
    
    startPlayback() {
        this.isPlaying = true;
        
        // Update button icon to pause
        const playBtn = document.getElementById('playBtn');
        if (playBtn) {
            playBtn.innerHTML = `
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" 
                    stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="6" y="4" width="4" height="16"></rect>
                    <rect x="14" y="4" width="4" height="16"></rect>
                </svg>
            `;
        }
        
        // Start from current scene
        let currentScene = this.currentSceneIndex;
        
        // Define playback function
        const playNextScene = () => {
            if (!this.isPlaying) return;
            
            this.showScene(currentScene);
            currentScene++;
            
            if (currentScene < this.scenes.length) {
                setTimeout(playNextScene, 3000); // 3 seconds per scene
            } else {
                this.stopPlayback();
            }
        };
        
        // Start playback
        playNextScene();
    }
    
    stopPlayback() {
        this.isPlaying = false;
        
        // Update button icon to play
        const playBtn = document.getElementById('playBtn');
        if (playBtn) {
            playBtn.innerHTML = `
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" 
                    stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <polygon points="5 3 19 12 5 21 5 3"></polygon>
                </svg>
            `;
        }
    }
}

// GeminiService class implementation
class GeminiService {
    constructor(apiKey) {
        this.apiKey = "AIzaSyA8uiAbK_rgUGi90zKKN7XhWlYaW3vTSBk";
        this.baseUrl = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-thinking-exp-1219:generateContent';
    }
    
    async generateStory(topic, style, sceneCount) {
        const prompt = `
            Create a story about "${topic}" in ${style} style with ${sceneCount} scenes.
            For each scene, provide:
            1. A title
            2. A detailed description
            3. Characters present
            4. Key actions and events
            5. Visual setting description
            
            Format the response as a JSON object with the following structure:
            {
                "title": "Story Title",
                "description": "Overall story description",
                "scenes": [
                    {
                        "id": 0,
                        "title": "Scene 1 Title",
                        "description": "Detailed scene description",
                        "setting": "Location/environment description",
                        "characters": [
                            {"id": "char1", "name": "Character Name", "description": "Character description"}
                        ],
                        "actions": ["Action 1", "Action 2"]
                    }
                ]
            }
        `;
        
        try {
            console.log('Sending request to Gemini API');
            const response = await fetch(`${this.baseUrl}?key=${this.apiKey}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    contents: [
                        {
                            parts: [
                                {
                                    text: prompt
                                }
                            ]
                        }
                    ]
                })
            });
            
            if (!response.ok) {
                console.log('Response status:', response.status, response.statusText);
                throw new Error(`Gemini API error: ${response.status}`);
            }

            const data = await response.json();
            console.log('Received response from Gemini API:', data);
            
            const textResponse = data.candidates[0].content.parts[0].text;
            
            // Extract JSON from text response
            const jsonMatch = textResponse.match(/```json\s*([\s\S]*?)\s*```/) || 
                             textResponse.match(/\{[\s\S]*\}/);
                             
            if (jsonMatch) {
                const jsonData = JSON.parse(jsonMatch[0].replace(/```json|```/g, '').trim());
                console.log('Parsed JSON data:', jsonData);
                return jsonData;
            } else {
                throw new Error('Failed to parse JSON response from Gemini');
            }
            
        } catch (error) {
            console.error('Error calling Gemini API:', error);
            throw error;
        }
    }
    
    async generateImage(description, style) {
        // Note: This would use Gemini's image generation capabilities
        // For the demo, we'll return a placeholder
        console.log(`Would generate image for: "${description}" in ${style} style`);
        
        // Return a placeholder data URL in real implementation
        return 'data:image/svg+xml;base64,...';
    }
}

// Initialize the app
document.addEventListener('DOMContentLoaded', () => {
    console.log('Initializing StoryCanvas app');
    try {
        const app = new StoryCanvas();
        window.storyCanvas = app; // For debugging
        console.log('StoryCanvas initialized successfully');
    } catch (error) {
        console.error('Error initializing StoryCanvas:', error);
    }
});