const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

// Modified color scheme
const colors = {
  background: "#e5f2c9", // Light greenish-yellow
  text: "#1e5631",       // Dark green
  player: "#14397d",     // Dark blue
  bubble: "#ffffff",     // White
  bulletColor: "#14397d",// Dark blue
  correctMessage: "#1e5631", // Dark green
  wrongMessage: "#d62828",   // Red for wrong answers
  bubbleBorder: "#14397d"    // Dark blue border
};

let questions = [
  { question: "What is 2 + 2?", answers: [4, 5, 3, 2], correct: 4 },
  { question: "What is 3 + 3?", answers: [5, 6, 7, 8], correct: 6 },
  { question: "What is 5 + 2?", answers: [8, 6, 7, 5], correct: 7 }
];

function createQuestionIterator(questions) {
  let index = 0;
  return {
    next: function () {
      if (index < questions.length) {
        return { value: questions[index++], done: false };
      } else {
        index = 0;
        return { value: questions[index++], done: false };
      }
    },
    reset: function () {
      index = 0;
    }
  };
}

let questionIterator = createQuestionIterator(questions);
let answers = [];
let bullets = [];
let playerX = 50;
let playerY = canvas.height / 2;
let score = 0;
let gameMessage = "";
let messageType = "";
let gameActive = true;
let selectedAnswer = null;
let scoreDisplay = document.getElementById("score");
let progressDisplay = document.getElementById("progress");
let currentQuestionIndex = 0;
let totalQuestions = questions.length;

function loadQuestion() {
  let questionObj = questionIterator.next().value;
  document.getElementById("question").innerText = questionObj.question;
  
  currentQuestionIndex = (currentQuestionIndex % questions.length) + 1;
  progressDisplay.innerText = `Question ${currentQuestionIndex} of ${totalQuestions}`;

  answers = questionObj.answers.map((answer, index) => ({
    answer: answer,
    x: 750,
    y: 100 + index * 100,
    isCorrect: answer === questionObj.correct,
    radius: 30 // Changed from rectangles to circles for a more bubble-like appearance
  }));

  gameActive = true;
  selectedAnswer = null;
  gameMessage = "";
  
  // Hide buttons when loading new question
  document.getElementById("nextBtn").style.display = "none";
  document.getElementById("restartBtn").style.display = "none";
}

function Bullet(x, y, target) {
  this.x = x;
  this.y = y;
  this.target = target;
  this.speed = 7;

  this.dx = target.x - x;
  this.dy = target.y - y;
  this.angle = Math.atan2(this.dy, this.dx);
  this.velocityX = Math.cos(this.angle) * this.speed;
  this.velocityY = Math.sin(this.angle) * this.speed;
}

function shootBullet(target) {
  bullets = [new Bullet(playerX + 50, playerY, target)];
  selectedAnswer = target;
}

function handleSelection(event) {
  if (!gameActive) return;
  
  const rect = canvas.getBoundingClientRect();
  let mouseX = event.clientX - rect.left;
  let mouseY = event.clientY - rect.top;
  
  // Scale coordinates if canvas is displayed at a different size
  mouseX = mouseX * (canvas.width / rect.width);
  mouseY = mouseY * (canvas.height / rect.height);

  for (let i = 0; i < answers.length; i++) {
    let answerObj = answers[i];
    // Check if click is within circle (bubble)
    const distance = Math.sqrt(
      Math.pow(mouseX - answerObj.x, 2) + 
      Math.pow(mouseY - answerObj.y, 2)
    );
    
    if (distance <= answerObj.radius) {
      shootBullet(answerObj);
      break;
    }
  }
}

// Make the Play Again button smaller
function updateButtonStyles() {
  const restartBtn = document.getElementById("restartBtn");
  restartBtn.style.padding = "8px 16px";
  restartBtn.style.fontSize = "16px";
}

function restartGame() {
  questionIterator.reset();
  currentQuestionIndex = 0;
  score = 0;
  gameActive = true;
  bullets = [];
  selectedAnswer = null;
  gameMessage = "";
  messageType = "";
  document.getElementById("nextBtn").style.display = "none";
  document.getElementById("restartBtn").style.display = "none";
  loadQuestion();
  requestAnimationFrame(updateGame);
}

document.getElementById("restartBtn").addEventListener("click", restartGame);

document.getElementById("quitBtn").addEventListener("click", function () {
  gameActive = false;
  gameMessage = `Game Over. Final Score: ${score}/${totalQuestions}`;
  messageType = "quit";
  document.getElementById("restartBtn").style.display = "block";
  updateGame();
});

function nextQuestion() {
  // Check if we've completed all questions
  if (currentQuestionIndex >= totalQuestions) {
    gameActive = false;
    messageType = "complete";
    document.getElementById("restartBtn").style.display = "block";
    document.getElementById("nextBtn").style.display = "none";
  } else {
    bullets = [];
    selectedAnswer = null;
    gameMessage = "";
    loadQuestion();
  }
  updateGame();
}

document.getElementById("nextBtn").addEventListener("click", nextQuestion);

// Draw the cannon/player
function drawPlayer() {
  ctx.fillStyle = colors.player;
  
  // Draw cannon base
  ctx.beginPath();
  ctx.arc(playerX, playerY, 25, 0, Math.PI * 2);
  ctx.fill();
  
  // Draw cannon barrel
  ctx.fillRect(playerX, playerY - 10, 50, 20);
}

// Display the result message on canvas
function displayResultMessage() {
  // Draw semi-transparent overlay
  ctx.fillStyle = "rgba(0, 0, 0, 0.3)";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  
  // Create message box - make it smaller to leave room for buttons
  const boxWidth = 400;
  const boxHeight = 150;
  const boxX = (canvas.width - boxWidth) / 2;
  const boxY = (canvas.height - boxHeight) / 2 - 30; // Move up a bit to make room for buttons
  
  // Draw message box
  ctx.fillStyle = "#ffffff";
  ctx.strokeStyle = messageType === "correct" ? colors.correctMessage : colors.wrongMessage;
  ctx.lineWidth = 6;
  ctx.beginPath();
  ctx.roundRect(boxX, boxY, boxWidth, boxHeight, 15);
  ctx.fill();
  ctx.stroke();
  
  // Draw message text
  ctx.fillStyle = messageType === "correct" ? colors.correctMessage : colors.wrongMessage;
  ctx.font = "bold 40px 'Comic Neue', cursive";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  
  // Draw icon and text
  const icon = messageType === "correct" ? "✓" : "✗";
  ctx.fillText(icon, canvas.width / 2, boxY + 50);
  
  // Draw message and score
  ctx.fillText(gameMessage, canvas.width / 2, boxY + 100);
}

function updateGame() {
  // Clear canvas and set background
  ctx.fillStyle = colors.background;
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  
  scoreDisplay.innerText = `Score: ${score}`;

  if (!gameActive && (messageType === "correct" || messageType === "wrong")) {
    // Draw the game elements in the background
    drawGameElements();
    // Draw the result message
    displayResultMessage();
    
    // Handle automatic transitions based on result
    if (messageType === "correct") {
      // For correct answers, show Next button
      document.getElementById("nextBtn").style.display = "block";
    } else if (messageType === "wrong") {
      // For wrong answers, show Restart button
      document.getElementById("restartBtn").style.display = "block";
    }
    return;
  } else if (!gameActive) {
    // Handle other game states (quit, complete)
    ctx.font = "bold 40px 'Comic Neue', cursive";
    ctx.fillStyle = colors.text;
    ctx.textAlign = "center";
    ctx.fillText(gameMessage, canvas.width / 2, canvas.height / 2 - 30);
    
    // Also display score for quit and complete messages
    ctx.font = "bold 24px 'Comic Neue', cursive";
    ctx.fillText(`Final Score: ${score}/${totalQuestions}`, canvas.width / 2, canvas.height / 2 + 20);
    return;
  }

  drawGameElements();
  
  // Continue animation
  if (gameActive || bullets.length > 0) {
    requestAnimationFrame(updateGame);
  }
}

function drawGameElements() {
  // Move answer bubbles from right to left if no answer is selected
  if (!selectedAnswer && gameActive) {
    for (let i = 0; i < answers.length; i++) {
      // Slow down the movement for better gameplay
      answers[i].x -= 1;
    }
  }

  // Draw answer bubbles
  for (let i = 0; i < answers.length; i++) {
    let answerObj = answers[i];
    
    // Draw bubble
    ctx.beginPath();
    ctx.arc(answerObj.x, answerObj.y, answerObj.radius, 0, Math.PI * 2);
    ctx.fillStyle = colors.bubble;
    ctx.fill();
    ctx.strokeStyle = colors.bubbleBorder;
    ctx.lineWidth = 2;
    ctx.stroke();
    
    // Draw answer text
    ctx.fillStyle = colors.text;
    ctx.font = "bold 20px 'Comic Neue', cursive";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(answerObj.answer, answerObj.x, answerObj.y);
  }

  // Update and draw bullets
  for (let j = bullets.length - 1; j >= 0; j--) {
    let bullet = bullets[j];
    bullet.x += bullet.velocityX;
    bullet.y += bullet.velocityY;
    
    ctx.fillStyle = colors.bulletColor;
    ctx.beginPath();
    ctx.arc(bullet.x, bullet.y, 8, 0, Math.PI * 2);
    ctx.fill();

    // Check for collision with target
    const dx = bullet.x - selectedAnswer.x;
    const dy = bullet.y - selectedAnswer.y;
    const distance = Math.sqrt(dx * dx + dy * dy);
    
    if (distance < selectedAnswer.radius) {
      gameActive = false;
      
      if (selectedAnswer.isCorrect) {
        score++;
        gameMessage = "CORRECT!";
        messageType = "correct";
        
        // Move to next question automatically after a delay
        setTimeout(function() {
          if (currentQuestionIndex === totalQuestions) {
            // If this was the last question
            gameMessage = `Game Complete!`;
            messageType = "complete";
            document.getElementById("restartBtn").style.display = "block";
            document.getElementById("nextBtn").style.display = "none";
          } else {
            document.getElementById("nextBtn").style.display = "block";
          }
          updateGame();
        }, 1500);
      } else {
        gameMessage = "WRONG!";
        messageType = "wrong";
        
        // Show restart button after a short delay
        setTimeout(function() {
          document.getElementById("restartBtn").style.display = "block";
          updateGame();
        }, 1500);
      }
      
      bullets = [];
      updateGame(); // Force immediate update to show the result
      return; // Exit the function to stop further updates until user action
    }
  }
  
  // Draw player
  drawPlayer();
}

// Handle window resize
window.addEventListener("resize", function() {
  // Force redraw on resize
  if (gameActive) {
    updateGame();
  }
});

// Call this at the start to make the Play Again button smaller
updateButtonStyles();

document.addEventListener("click", handleSelection);
loadQuestion();
updateGame();